<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePetCareJournalTables extends Migration
{
    public function up()
    {
        // -------- users --------
        $this->forge->addField([
            'id'         => ['type' => 'INT',     'constraint' => 11,  'unsigned' => true, 'auto_increment' => true],
            'email'      => ['type' => 'VARCHAR', 'constraint' => 100],
            'password'   => ['type' => 'VARCHAR', 'constraint' => 255],
            'name'       => ['type' => 'VARCHAR', 'constraint' => 100],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);          // primary
        $this->forge->addUniqueKey('email');       // unique key utk email (jangan di field) (periksa lagii nanti)
        $this->forge->createTable('users', true);

        // -------- pet_journals --------
        $this->forge->addField([
            'id'         => ['type' => 'INT',     'constraint' => 11,  'unsigned' => true, 'auto_increment' => true],
            'user_id'    => ['type' => 'INT',     'constraint' => 11,  'unsigned' => true],
            'pet_name'   => ['type' => 'VARCHAR', 'constraint' => 100],
            'pet_photo'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'pet_type'   => ['type' => 'VARCHAR', 'constraint' => 50],
            'birthdate'  => ['type' => 'DATE',     'null' => true],

            'gender'     => ['type' => 'ENUM',    'constraint' => ['jantan', 'betina'], 'null' => true],
            'race'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'notes'      => ['type' => 'TEXT',     'null' => true],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('pet_journals', true);
    }

    public function down()
    {
        // urutan drop: anak dulu baru induk  )
        $this->forge->dropTable('pet_journals', true);
        $this->forge->dropTable('users', true);
    }
}
