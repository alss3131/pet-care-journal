<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Login Routes (loginnya disini)
$routes->get('/', 'AuthController::index');
$routes->get('login', 'AuthController::index');
$routes->post('auth/login', 'AuthController::login');
$routes->get('auth/logout', 'AuthController::logout');

// Register Routes 
$routes->get('register', 'AuthController::register');
$routes->post('auth/register', 'AuthController::doRegister');

// Protected Routes (require login)
$routes->group('', ['filter' => 'auth'], function($routes) {
    // Home/Dashboard
    $routes->get('home', 'HomeController::index');

    // Pet Journal CRUD
    $routes->get('journal/create', 'JournalController::create');
    $routes->post('journal/store', 'JournalController::store');
    $routes->get('journal/edit/(:num)', 'JournalController::edit/$1');
    $routes->post('journal/update/(:num)', 'JournalController::update/$1');
    $routes->get('journal/delete/(:num)', 'JournalController::delete/$1');
    $routes->get('journal/detail/(:num)', 'JournalController::detail/$1');
});