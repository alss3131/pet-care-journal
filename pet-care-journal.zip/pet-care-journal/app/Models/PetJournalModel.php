<?php

namespace App\Models;

use CodeIgniter\Model;

class PetJournalModel extends Model
{
    protected $table = 'pet_journals';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id',
        'pet_name',
        'pet_photo',
        'pet_type',
        'birthdate',
        'gender',
        'race',
        'notes'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}