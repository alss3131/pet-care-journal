<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Journal - Register</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f5f5f5;min-height:100vh;display:flex;flex-direction:column}
    .header-bar{background:#b8e986;height:50px;width:100%}
    .login-container{flex:1;display:flex;justify-content:center;align-items:center;padding:20px}
    .login-card{background:#fff;border-radius:15px;box-shadow:0 4px 20px rgba(0,0,0,.1);padding:50px;max-width:500px;width:100%}
    .login-card h1{font-size:36px;font-weight:bold;margin-bottom:10px;color:#333}
    .login-card p{color:#666;margin-bottom:30px;font-size:14px}
    .form-label{display:block;margin-bottom:15px;font-weight:600;color:#333}
    .form-group{margin-bottom:20px}
    .form-input{width:100%;padding:12px 15px;border:none;background:#e8f5d4;border-radius:8px;font-size:14px;outline:none;transition:background .3s}
    .form-input:focus{background:#d4edb8}
    .btn-register{background:#b8e986;color:#333;border:none;padding:12px 40px;border-radius:8px;font-weight:600;cursor:pointer;font-size:14px;transition:background .3s;margin-top:10px;width:100%}
    .btn-register:hover{background:#a8d976}
    .alert{padding:12px 20px;border-radius:8px;margin-bottom:20px}
    .alert-error{background:#ffe6e6;color:#cc0000;border:1px solid #ffcccc}
    .login-link{text-align:center;margin-top:20px;color:#666;font-size:14px}
    .login-link a{color:#4CAF50;text-decoration:none;font-weight:600}
    .login-link a:hover{text-decoration:underline}
  </style>
</head>
<body>
  <div class="header-bar"></div>
  <div class="login-container">
    <div class="login-card">
      <h1>Register</h1>
      <p>Buat akun baru untuk Pet Journal</p>

      <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-error">
          <?php foreach (session()->getFlashdata('errors') as $error): ?>
            <p><?= esc($error) ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form action="<?= base_url('auth/register') ?>" method="POST">
        <?= csrf_field() ?>

        <div class="form-label">Isi data berikut :</div>

        <div class="form-group">
          <input type="text" name="name" class="form-input" placeholder="Nama Lengkap" required value="<?= old('name') ?>">
        </div>

        <div class="form-group">
          <input type="email" name="email" class="form-input" placeholder="Email" required value="<?= old('email') ?>">
        </div>

        <div class="form-group">
          <input type="password" name="password" class="form-input" placeholder="Password (min. 6 karakter)" required>
        </div>

        <div class="form-group">
          <input type="password" name="password_confirm" class="form-input" placeholder="Konfirmasi Password" required>
        </div>

        <button type="submit" class="btn-register">Register</button>
      </form>

      <div class="login-link">
        Sudah punya akun? <a href="<?= base_url('login') ?>">Login di sini</a>
      </div>
    </div>
  </div>
</body>
</html>
