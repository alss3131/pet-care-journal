<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Journal - Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header-bar {
            background: #b8e986;
            height: 50px;
            width: 100%;
        }

        .login-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 50px;
            max-width: 900px;
            width: 100%;
            display: flex;
            gap: 60px;
            align-items: center;
        }

        .login-left {
            flex: 1;
        }

        .login-left h1 {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }

        .login-left p {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .form-label {
            display: block;
            margin-bottom: 15px;
            font-weight: 600;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: none;
            background: #e8f5d4;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: background 0.3s;
        }

        .form-input:focus {
            background: #d4edb8;
        }

        .btn-login {
            background: #ffb3b3;
            color: #333;
            border: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: #ff9999;
        }

        .login-right {
            flex: 1;
            text-align: center;
        }

        .login-right img {
            max-width: 100%;
            height: auto;
        }

        .alert {
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffcccc;
        }

        .alert-success {
            background: #e6ffe6;
            color: #006600;
            border: 1px solid #ccffcc;
        }

        @media (max-width: 768px) {
            .login-card {
                flex-direction: column;
                padding: 30px;
            }

            .login-left h1 {
                font-size: 36px;
            }

            .login-right {
                order: -1;
            }
        }
    </style>
</head>
<body>
    <div class="header-bar"></div>
    
    <div class="login-container">
        <div class="login-card">
            <div class="login-left">
                <h1>Pet Journal</h1>
                <p>Dokumentasikan perkembangan hewan peliharaanmu</p>

                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-error">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>

                <form action="<?= base_url('auth/login') ?>" method="POST">
                    <?= csrf_field() ?>
                    
                    <div class="form-label">Isi data berikut :</div>
                    
                    <div class="form-group">
                        <input 
                            type="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="Email :" 
                            required
                            value="<?= old('email') ?>"
                        >
                    </div>

                    <div class="form-group">
                        <input
                            type="password"
                            name="password"
                            class="form-input"
                            placeholder="Password :"
                            required
                        >
                    </div>

                    <button type="submit" class="btn-login">Login</button>
                </form>

                <div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">
                    Belum punya akun? <a href="<?= base_url('register') ?>" style="color: #4CAF50; text-decoration: none; font-weight: 600;">Register di sini</a>
                </div>
            </div>

            <div class="login-right">
                <img src="<?= base_url('assets/img/login.png') ?>" alt="Ilustrasi">
            </div>
        </div>
    </div>
</body>
</html>