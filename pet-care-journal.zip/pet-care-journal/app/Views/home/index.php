<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }

        .header-bar {
            background: #b8e986;
            height: 50px;
            display: flex;
            align-items: center;
            padding: 0 30px;
            justify-content: space-between;
        }

        .navbar {
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .nav-link {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-link:hover {
            color: #555;
        }

        .nav-link.active {
            font-weight: 700;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .header-left h1 {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .header-left p {
            color: #666;
            font-size: 14px;
        }

        .header-right img {
            width: 200px;
            height: auto;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }

        .btn-create {
            background: #b8e986;
            color: #333;
            text-decoration: none;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.3s;
        }

        .btn-create:hover {
            background: #a8d976;
        }

        .pets-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .pet-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            cursor: pointer;
        }

        .pet-card:hover {
            transform: translateY(-5px);
        }

        .pet-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #e0e0e0;
        }

        .pet-info {
            padding: 15px;
            text-align: center;
        }

        .pet-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state svg {
            margin-bottom: 20px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #e6ffe6;
            color: #006600;
            border: 1px solid #ccffcc;
        }

        .alert-error {
            background: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffcccc;
        }

        @media (max-width: 768px) {
            .header-section {
                flex-direction: column;
                text-align: center;
            }

            .header-right {
                order: -1;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <div class="navbar">
            <a href="<?= base_url('home') ?>" class="nav-link active">Home</a>
        </div>
        <div class="navbar">
            <span class="nav-link"><?= session()->get('name') ?></span>
            <a href="<?= base_url('auth/logout') ?>" class="nav-link">Logout</a>
        </div>
    </div>

    <div class="container">
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-error">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <div class="header-section">
            <div class="header-left">
                <h1>Pet Journal</h1>
                <p>Dokumentasikan perkembangan hewan peliharaanmu</p>
            </div>
            <div class="header-right">
                <img src="<?= base_url('assets/img/pets.png') ?>" alt="Ilustrasi" />
            </div>
        </div>

        <div class="section-title">Buat Catatanmu :</div>
        <a href="<?= base_url('journal/create') ?>" class="btn-create">
            <span>+</span> Create New
        </a>

        <div class="pets-grid">
            <?php if (empty($pets)): ?>
                <div class="empty-state" style="grid-column: 1/-1;">
                    <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="50" cy="50" r="40" stroke="#ddd" stroke-width="3"/>
                        <path d="M 35 45 Q 40 35 45 45" stroke="#ddd" stroke-width="3" stroke-linecap="round"/>
                        <path d="M 55 45 Q 60 35 65 45" stroke="#ddd" stroke-width="3" stroke-linecap="round"/>
                        <path d="M 35 65 Q 50 75 65 65" stroke="#ddd" stroke-width="3" stroke-linecap="round"/>
                    </svg>
                    <p>Belum ada catatan hewan peliharaan</p>
                </div>
            <?php else: ?>
                <?php foreach ($pets as $pet): ?>
                    <a href="<?= base_url('journal/detail/' . $pet['id']) ?>" style="text-decoration: none; color: inherit;">
                        <div class="pet-card">
                            <?php if ($pet['pet_photo']): ?>
                                <img src="<?= base_url('uploads/pets/' . $pet['pet_photo']) ?>" alt="<?= $pet['pet_name'] ?>" class="pet-image">
                            <?php else: ?>
                                <div class="pet-image" style="display: flex; align-items: center; justify-content: center; background: #e0e0e0;">
                                    <svg width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="50" cy="40" r="20" fill="#999"/>
                                        <ellipse cx="50" cy="75" rx="30" ry="20" fill="#999"/>
                                    </svg>
                                </div>
                            <?php endif; ?>
                            <div class="pet-info">
                                <div class="pet-name"><?= esc($pet['pet_name']) ?></div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>