<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }

        .header-bar {
            background: #b8e986;
            height: 50px;
            display: flex;
            align-items: center;
            padding: 0 30px;
            justify-content: space-between;
        }

        .navbar {
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .nav-link {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-link:hover {
            color: #555;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .header-section {
            margin-bottom: 40px;
        }

        .header-section h1 {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .header-section p {
            color: #666;
            font-size: 14px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }

        .form-container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .form-left {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .photo-upload {
            width: 100%;
            height: 300px;
            border: 3px dashed #ddd;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            background: #fafafa;
        }

        .photo-upload:hover {
            border-color: #b8e986;
            background: #f5f5f5;
        }

        .photo-upload input[type="file"] {
            display: none;
        }

        .photo-preview {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .photo-upload svg {
            margin-bottom: 15px;
        }

        .photo-upload p {
            color: #999;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
        }

        .form-input:focus {
            border-color: #b8e986;
        }

        .form-textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            resize: vertical;
            min-height: 100px;
            font-family: inherit;
        }

        .form-textarea:focus {
            border-color: #b8e986;
        }

        .btn-submit {
            background: #b8e986;
            color: #333;
            border: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }

        .btn-submit:hover {
            background: #a8d976;
        }

        .btn-back {
            background: #e0e0e0;
            color: #333;
            text-decoration: none;
            padding: 12px 40px;
            border-radius: 8px;
            font-weight: 600;
            display: inline-block;
            transition: background 0.3s;
            margin-right: 10px;
        }

        .btn-back:hover {
            background: #d0d0d0;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffcccc;
        }

        .current-photo {
            font-size: 12px;
            color: #666;
            margin-top: 10px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <div class="navbar">
            <a href="<?= base_url('home') ?>" class="nav-link">Home</a>
        </div>
        <div class="navbar">
            <span class="nav-link"><?= session()->get('name') ?></span>
            <a href="<?= base_url('auth/logout') ?>" class="nav-link">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="header-section">
            <h1>Pet Journal</h1>
            <p>Dokumentasikan perkembangan hewan peliharaanmu</p>
        </div>

        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-error">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <p><?= $error ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="section-title">Edit Catatan</div>

        <div class="form-container">
            <form action="<?= base_url('journal/update/' . $pet['id']) ?>" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                
                <div class="form-grid">
                    <div class="form-left">
                        <label class="photo-upload" id="photoLabel">
                            <input type="file" name="pet_photo" id="photoInput" accept="image/*">
                            <?php if ($pet['pet_photo']): ?>
                                <img id="photoPreview" class="photo-preview" src="<?= base_url('uploads/pets/' . $pet['pet_photo']) ?>" style="display: block;">
                            <?php else: ?>
                                <img id="photoPreview" class="photo-preview">
                                <div id="uploadPlaceholder">
                                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="10" y="15" width="40" height="35" rx="4" stroke="#999" stroke-width="2"/>
                                        <circle cx="30" cy="30" r="8" stroke="#999" stroke-width="2"/>
                                        <path d="M 20 45 L 28 35 L 35 42 L 42 32 L 48 40" stroke="#999" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                    <p>Klik untuk upload foto baru</p>
                                </div>
                            <?php endif; ?>
                        </label>
                        <?php if ($pet['pet_photo']): ?>
                            <div class="current-photo">Klik untuk mengganti foto</div>
                        <?php endif; ?>
                    </div>

                    <div class="form-right">
                        <div class="form-group">
                            <label class="form-label">Nama Hewan Peliharaan</label>
                            <input type="text" name="pet_name" class="form-input" value="<?= esc($pet['pet_name']) ?>" placeholder="Masukkan nama..." required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Jenis Hewan</label>
                            <input type="text" name="pet_type" class="form-input" value="<?= esc($pet['pet_type']) ?>" placeholder="Contoh: Kucing, Anjing..." required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" name="birthdate" class="form-input" value="<?= $pet['birthdate'] ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="gender" class="form-input" required>
                                <option value="">Pilih...</option>
                                <option value="jantan" <?= $pet['gender'] == 'jantan' ? 'selected' : '' ?>>Jantan</option>
                                <option value="betina" <?= $pet['gender'] == 'betina' ? 'selected' : '' ?>>Betina</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Ras/Jenis</label>
                            <input type="text" name="race" class="form-input" value="<?= esc($pet['race']) ?>" placeholder="Contoh: Persian, Golden Retriever...">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Catatan Tambahan</label>
                    <textarea name="notes" class="form-textarea" placeholder="Tambahkan catatan tentang hewan peliharaanmu..."><?= esc($pet['notes']) ?></textarea>
                </div>

                <div>
                    <a href="<?= base_url('journal/detail/' . $pet['id']) ?>" class="btn-back">Kembali</a>
                    <button type="submit" class="btn-submit">Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const photoInput = document.getElementById('photoInput');
        const photoPreview = document.getElementById('photoPreview');
        const uploadPlaceholder = document.getElementById('uploadPlaceholder');

        photoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    photoPreview.src = e.target.result;
                    photoPreview.style.display = 'block';
                    if (uploadPlaceholder) {
                        uploadPlaceholder.style.display = 'none';
                    }
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>