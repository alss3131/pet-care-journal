<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }

        .header-bar {
            background: #b8e986;
            height: 50px;
            display: flex;
            align-items: center;
            padding: 0 30px;
            justify-content: space-between;
        }

        .navbar {
            display: flex;
            gap: 30px;
            align-items: center;
        }

        .nav-link {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-link:hover {
            color: #555;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .header-section {
            margin-bottom: 40px;
        }

        .header-section h1 {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .header-section p {
            color: #666;
            font-size: 14px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }

        .detail-container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }

        .detail-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 40px;
            margin-bottom: 30px;
        }

        .pet-photo {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-radius: 12px;
            background: #e0e0e0;
        }

        .detail-info {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .info-card {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #b8e986;
        }

        .info-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-value {
            color: #555;
            font-size: 16px;
            line-height: 1.6;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            border: none;
        }

        .btn-back {
            background: #e0e0e0;
            color: #333;
        }

        .btn-back:hover {
            background: #d0d0d0;
        }

        .btn-edit {
            background: #b8e986;
            color: #333;
        }

        .btn-edit:hover {
            background: #a8d976;
        }

        .btn-delete {
            background: #ff6b6b;
            color: white;
        }

        .btn-delete:hover {
            background: #ff5252;
        }

        .notes-section {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }

        .notes-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 12px;
            font-size: 16px;
        }

        .notes-content {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            color: #555;
            line-height: 1.8;
            white-space: pre-wrap;
        }

        @media (max-width: 768px) {
            .detail-grid {
                grid-template-columns: 1fr;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <div class="navbar">
            <a href="<?= base_url('home') ?>" class="nav-link">Home</a>
        </div>
        <div class="navbar">
            <span class="nav-link"><?= session()->get('name') ?></span>
            <a href="<?= base_url('auth/logout') ?>" class="nav-link">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="header-section">
            <h1>Pet Journal</h1>
            <p>Dokumentasikan perkembangan hewan peliharaanmu</p>
        </div>

        <div class="section-title">Detail Catatan</div>

        <div class="detail-container">
            <div class="detail-grid">
                <div>
                    <?php if ($pet['pet_photo']): ?>
                        <img src="<?= base_url('uploads/pets/' . $pet['pet_photo']) ?>" alt="<?= esc($pet['pet_name']) ?>" class="pet-photo">
                    <?php else: ?>
                        <div class="pet-photo" style="display: flex; align-items: center; justify-content: center;">
                            <svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="50" cy="35" r="20" fill="#999"/>
                                <ellipse cx="50" cy="70" rx="30" ry="20" fill="#999"/>
                                <circle cx="42" cy="32" r="3" fill="#fff"/>
                                <circle cx="58" cy="32" r="3" fill="#fff"/>
                            </svg>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="detail-info">
                    <div class="info-card">
                        <div class="info-title">Nama Hewan Peliharaan</div>
                        <div class="info-value"><?= esc($pet['pet_name']) ?></div>
                    </div>

                    <div class="info-grid">
                        <div class="info-card">
                            <div class="info-title">Jenis Hewan</div>
                            <div class="info-value"><?= esc($pet['pet_type']) ?></div>
                        </div>

                        <div class="info-card">
                            <div class="info-title">Jenis Kelamin</div>
                            <div class="info-value"><?= ucfirst($pet['gender']) ?></div>
                        </div>
                    </div>

                    <div class="info-grid">
                        <div class="info-card">
                            <div class="info-title">Tanggal Lahir</div>
                            <div class="info-value">
                                <?php if ($pet['birthdate']): ?>
                                    <?= date('d F Y', strtotime($pet['birthdate'])) ?>
                                <?php else: ?>
                                    <em style="color: #999;">Tidak diisi</em>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="info-card">
                            <div class="info-title">Ras/Jenis</div>
                            <div class="info-value">
                                <?= $pet['race'] ? esc($pet['race']) : '<em style="color: #999;">Tidak diisi</em>' ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($pet['notes']): ?>
            <div class="notes-section">
                <div class="notes-title">Catatan Tambahan</div>
                <div class="notes-content"><?= esc($pet['notes']) ?></div>
            </div>
            <?php endif; ?>

            <div class="action-buttons">
                <a href="<?= base_url('home') ?>" class="btn btn-back">Kembali</a>
                <a href="<?= base_url('journal/edit/' . $pet['id']) ?>" class="btn btn-edit">Edit</a>
                <a href="<?= base_url('journal/delete/' . $pet['id']) ?>" 
                   class="btn btn-delete" 
                   onclick="return confirm('Apakah Anda yakin ingin menghapus catatan ini?')">
                    Hapus
                </a>
            </div>
        </div>
    </div>
</body>
</html>