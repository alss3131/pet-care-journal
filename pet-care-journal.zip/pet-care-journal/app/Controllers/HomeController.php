<?php

namespace App\Controllers;

use App\Models\PetJournalModel;

class HomeController extends BaseController
{
    protected $petJournalModel;

    public function __construct()
    {
        $this->petJournalModel = new PetJournalModel();
    }

    public function index()
    {
        $userId = session()->get('user_id');

        $data = [
            'title' => 'Pet Journal - Home',
            'pets' => $this->petJournalModel->where('user_id', $userId)->findAll()
        ];

        return view('home/index', $data);
    }
}