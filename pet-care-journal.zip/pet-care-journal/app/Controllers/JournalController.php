<?php

namespace App\Controllers;

use App\Models\PetJournalModel;

class JournalController extends BaseController
{
    protected $petJournalModel;

    public function __construct()
    {
        $this->petJournalModel = new PetJournalModel();
        helper(['form', 'filesystem']);
    }

    public function create()
    {
        $data = [
            'title' => 'Tambah Catatan Baru'
        ];

        return view('journal/create', $data);
    }

    public function store()
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'pet_name' => 'required|min_length[3]',
            'pet_type' => 'required',
            'gender' => 'required',
            'pet_photo' => 'uploaded[pet_photo]|max_size[pet_photo,2048]|is_image[pet_photo]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $photo = $this->request->getFile('pet_photo');
        $photoName = null;

        if ($photo->isValid() && !$photo->hasMoved()) {
            $photoName = $photo->getRandomName();
            $photo->move(WRITEPATH . '../public/uploads/pets', $photoName);
        }

        $data = [
            'user_id' => session()->get('user_id'),
            'pet_name' => $this->request->getPost('pet_name'),
            'pet_photo' => $photoName,
            'pet_type' => $this->request->getPost('pet_type'),
            'birthdate' => $this->request->getPost('birthdate'),
            'gender' => $this->request->getPost('gender'),
            'race' => $this->request->getPost('race'),
            'notes' => $this->request->getPost('notes')
        ];

        $this->petJournalModel->insert($data);

        return redirect()->to('/home')->with('success', 'Catatan berhasil ditambahkan!');
    }

    public function edit($id)
    {
        $pet = $this->petJournalModel->find($id);

        if (!$pet || $pet['user_id'] != session()->get('user_id')) {
            return redirect()->to('/home')->with('error', 'Data tidak ditemukan!');
        }

        $data = [
            'title' => 'Edit Catatan',
            'pet' => $pet
        ];

        return view('journal/edit', $data);
    }

    public function update($id)
    {
        $pet = $this->petJournalModel->find($id);

        if (!$pet || $pet['user_id'] != session()->get('user_id')) {
            return redirect()->to('/home')->with('error', 'Data tidak ditemukan!');
        }

        $validation = \Config\Services::validation();
        $validation->setRules([
            'pet_name' => 'required|min_length[3]',
            'pet_type' => 'required',
            'gender' => 'required'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $photo = $this->request->getFile('pet_photo');
        $photoName = $pet['pet_photo'];

        if ($photo && $photo->isValid() && !$photo->hasMoved()) {
            if ($pet['pet_photo'] && file_exists(WRITEPATH . '../public/uploads/pets/' . $pet['pet_photo'])) {
                unlink(WRITEPATH . '../public/uploads/pets/' . $pet['pet_photo']);
            }

            $photoName = $photo->getRandomName();
            $photo->move(WRITEPATH . '../public/uploads/pets', $photoName);
        }

        $data = [
            'pet_name' => $this->request->getPost('pet_name'),
            'pet_photo' => $photoName,
            'pet_type' => $this->request->getPost('pet_type'),
            'birthdate' => $this->request->getPost('birthdate'),
            'gender' => $this->request->getPost('gender'),
            'race' => $this->request->getPost('race'),
            'notes' => $this->request->getPost('notes')
        ];

        $this->petJournalModel->update($id, $data);

        return redirect()->to('/home')->with('success', 'Catatan berhasil diupdate!');
    }

    public function delete($id)
    {
        $pet = $this->petJournalModel->find($id);
        
        if (!$pet || $pet['user_id'] != session()->get('user_id')) {
            return redirect()->to('/home')->with('error', 'Data tidak ditemukan!');
        }

        if ($pet['pet_photo'] && file_exists(WRITEPATH . '../public/uploads/pets/' . $pet['pet_photo'])) {
            unlink(WRITEPATH . '../public/uploads/pets/' . $pet['pet_photo']);
        }

        $this->petJournalModel->delete($id);

        return redirect()->to('/home')->with('success', 'Catatan berhasil dihapus!');
    }

    public function detail($id)
    {
        $pet = $this->petJournalModel->find($id);

        if (!$pet || $pet['user_id'] != session()->get('user_id')) {
            return redirect()->to('/home')->with('error', 'Data tidak ditemukan!');
        }

        $data = [
            'title' => 'Detail Catatan',
            'pet' => $pet
        ];

        return view('journal/detail', $data);
    }
}